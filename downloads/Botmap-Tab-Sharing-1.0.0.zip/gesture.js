// Runs in the extension's isolated world, inside the document named by the browser.
// All operations are fixed here. The peer supplies coordinates or text, never code or selectors.
export function applyGesture(g,width,height) {
  if (innerWidth!==width || innerHeight!==height) return false;
  let x=Math.min(width-1,Math.floor(g.x*width)),y=Math.min(height-1,Math.floor(g.y*height));
  let doc=window.document,view=window;
  let el=Number.isFinite(x)?doc.elementFromPoint(x,y):doc.activeElement;
  while(el instanceof view.HTMLIFrameElement){
    const child=el.contentDocument;
    if(!child || !child.defaultView)return false;
    const rect=el.getBoundingClientRect();
    if(Number.isFinite(x)){x=(x-rect.left)*el.offsetWidth/rect.width-el.clientLeft;y=(y-rect.top)*el.offsetHeight/rect.height-el.clientTop;}
    doc=child;view=child.defaultView;
    el=Number.isFinite(x)?doc.elementFromPoint(x,y):doc.activeElement;
  }
  while (el?.shadowRoot) {
    const inner=Number.isFinite(x)?el.shadowRoot.elementFromPoint(x,y):el.shadowRoot.activeElement;
    if(!inner || inner===el)break;
    el=inner;
  }
  if (!(el instanceof view.HTMLElement) || el.closest('iframe,frame,[inert]')) return false;
  if (g.type==='scroll') {
    for (let n=el;n;n=n.parentElement) {
      const style=view.getComputedStyle(n);
      if ((g.dy && n.scrollHeight>n.clientHeight && /auto|scroll/.test(style.overflowY)) ||
          (g.dx && n.scrollWidth>n.clientWidth && /auto|scroll/.test(style.overflowX))) {
        const oldX=n.scrollLeft,oldY=n.scrollTop;n.scrollBy(g.dx,g.dy);
        if(n.scrollTop!==oldY || n.scrollLeft!==oldX)return true;
      }
    }
    view.scrollBy(g.dx,g.dy);return true;
  }
  const textField=el instanceof view.HTMLTextAreaElement || el instanceof view.HTMLInputElement && ['text','search','url','tel','email'].includes(el.type);
  if (g.type==='click') {
    if(el.matches(':disabled,input[type=file]'))return false;
    const args={bubbles:true,composed:true,cancelable:true,clientX:x,clientY:y,button:0,view};
    const down=el.dispatchEvent(new PointerEvent('pointerdown',{...args,buttons:1,pointerType:'mouse'}));
    if(down && el.dispatchEvent(new MouseEvent('mousedown',{...args,buttons:1}))) el.focus({preventScroll:true});
    if(textField && el.selectionStart!==null) {
      // Hit-test in an identically styled text box, including wrapped lines,
      // horizontal scrolling, RTL text and variable-width glyphs.
      const box=el.getBoundingClientRect(),style=view.getComputedStyle(el),mirror=doc.createElement('div');
      for(const prop of style)mirror.style.setProperty(prop,style.getPropertyValue(prop));
      Object.assign(mirror.style,{position:'fixed',top:box.top+'px',left:box.left+'px',margin:'0',width:box.width+'px',
        height:box.height+'px',boxSizing:'border-box',opacity:'0',overflow:'hidden',zIndex:'2147483647',pointerEvents:'auto',
        transform:'none',whiteSpace:el instanceof view.HTMLTextAreaElement?'pre-wrap':'pre'});
      mirror.append(doc.createTextNode(el.value || ' '));doc.documentElement.append(mirror);
      try {
        mirror.scrollLeft=el.scrollLeft;mirror.scrollTop=el.scrollTop;
        const pos=doc.caretPositionFromPoint?.(x,y);
        if(pos?.offsetNode===mirror.firstChild){const offset=Math.min(pos.offset,el.value.length);el.setSelectionRange(offset,offset);}
      } finally {mirror.remove();}
    }
    if(el.isContentEditable) {
      const pos=doc.caretPositionFromPoint?.(x,y);
      if(pos && el.contains(pos.offsetNode))view.getSelection()?.collapse(pos.offsetNode,pos.offset);
    }
    el.dispatchEvent(new PointerEvent('pointerup',{...args,pointerType:'mouse'}));el.dispatchEvent(new MouseEvent('mouseup',args));
    el.dispatchEvent(new MouseEvent('click',args));return true;
  }
  if (g.type==='text') {
    if ((!textField && !el.isContentEditable) || el.readOnly || el.disabled) return false;
    if (!el.dispatchEvent(new InputEvent('beforeinput',{data:g.text,inputType:'insertText',bubbles:true,cancelable:true,composed:true}))) return true;
    return doc.execCommand('insertText',false,g.text);
  }
  if(g.type!=='key')return false;
  const key=g.key,selection=view.getSelection();
  const ev={key,bubbles:true,cancelable:true,composed:true,shiftKey:g.shift};
  const accepted=el.dispatchEvent(new KeyboardEvent('keydown',ev));
  try{
    if(!accepted)return true;
    if (el instanceof view.HTMLSelectElement && ['ArrowUp','ArrowDown','Home','End'].includes(key)) {
      const direction=key==='ArrowUp' || key==='End'?-1:1;
      let index=key==='Home'?0:key==='End'?el.options.length-1:el.selectedIndex+direction;
      while(el.options[index]?.disabled)index+=direction;
      if(el.options[index]){el.selectedIndex=index;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
      return true;
    }
    if(key==='Tab'){
      const items=[...doc.querySelectorAll('a[href],button,input,select,textarea,[tabindex],[contenteditable=true]')].filter(e=>e.tabIndex>=0&&!e.matches(':disabled')&&e.getClientRects().length);
      if(!items.length)return false;items[(items.indexOf(el)+(g.shift?-1:1)+items.length)%items.length].focus();return true;
    }
    if(key==='Enter' && !g.shift && el instanceof view.HTMLInputElement && el.form){el.form.requestSubmit();return true;}
    if(key==='Enter' && el.matches('button,a[href]')){el.click();return true;}
    if(!textField && !el.isContentEditable || el.readOnly || el.disabled)return false;
    if(key==='SelectAll'){if(textField)el.select();else selection?.selectAllChildren(el);return true;}
    if(key==='Backspace' || key==='Delete')return doc.execCommand(key==='Backspace'?'delete':'forwardDelete');
    if(key==='Enter')return doc.execCommand('insertLineBreak');
    if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(key)){
      const dir=['ArrowLeft','ArrowUp','Home'].includes(key)?'backward':'forward';
      selection?.modify(g.shift?'extend':'move',dir,['Home','End'].includes(key)?'lineboundary':['ArrowUp','ArrowDown'].includes(key)?'line':'character');return true;
    }
    return false;
  }finally{el.dispatchEvent(new KeyboardEvent('keyup',ev));}
}
