const feeds=new Map();
function remove(tab) {
  const feed=feeds.get(tab);feeds.delete(tab);
  if(feed){feed.stream.getTracks().forEach(t=>t.stop());feed.video.srcObject=null;}
}
function outputSize(width,height) {
  const scale=Math.min(1,1280/width,900/height);
  return {width:Math.max(2,2*Math.round(width*scale/2)),height:Math.max(2,2*Math.round(height*scale/2))};
}
async function capture(msg) {
  if(msg.op==='stop'){remove(msg.tab);return true;}
  if(msg.op==='start'){
    remove(msg.tab);
    const size=outputSize(msg.width,msg.height);
    const stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{mandatory:{chromeMediaSource:'tab',chromeMediaSourceId:msg.streamId,minWidth:size.width,maxWidth:size.width,minHeight:size.height,maxHeight:size.height}}});
    const video=document.createElement('video');video.muted=true;video.srcObject=stream;
    const feed={stream,video,size,at:Date.now(),canvas:document.createElement('canvas')};feeds.set(msg.tab,feed);
    stream.getVideoTracks()[0].onended=()=>{if(feeds.get(msg.tab)===feed){remove(msg.tab);void chrome.runtime.sendMessage({to:'worker',type:'ended',tab:msg.tab});}};
    await video.play();return true;
  }
  const feed=feeds.get(msg.tab);
  if(!feed)return null;
  feed.at=Date.now();
  if(!feed.video.videoWidth || feed.video.readyState<2)return {waiting:true};
  const size=outputSize(msg.width,msg.height);
  if(size.width!==feed.size.width || size.height!==feed.size.height){
    // A transient window animation can request a size the capturer cannot
    // produce. Keep the track alive; the worker verifies the actual frame.
    await feed.stream.getVideoTracks()[0].applyConstraints({width:{ideal:size.width},height:{ideal:size.height}});
    feed.size=size;
    return {waiting:true};
  }
  const {video,canvas}=feed,scale=Math.min(1,1280/video.videoWidth,900/video.videoHeight);
  const w=Math.max(1,Math.round(video.videoWidth*scale)),h=Math.max(1,Math.round(video.videoHeight*scale));
  if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
  canvas.getContext('2d',{alpha:false}).drawImage(video,0,0,w,h);
  return {image:canvas.toDataURL('image/jpeg',.68),width:video.videoWidth,height:video.videoHeight};
}
chrome.runtime.onMessage.addListener((m,s,send)=>{if(m.to!=='offscreen'||s.id!==chrome.runtime.id)return false;capture(m).then(send,e=>send({error:e.name||'CaptureError'}));return true;});

// Stop capture if the service worker or Botmap disappears mid-session.
setInterval(()=>{for(const [tab,feed] of feeds)if(Date.now()-feed.at>8000)remove(tab);},2000);
