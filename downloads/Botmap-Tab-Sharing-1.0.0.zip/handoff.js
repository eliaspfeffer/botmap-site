// Capture the fragment at document_start, before the owner page clears its URL.
// A browser can reuse an existing setup tab for the next share.
if (window === window.top && location.origin === 'http://127.0.0.1:44173') {
  const loaded = document.readyState === 'loading'
    ? new Promise(resolve=>document.addEventListener('DOMContentLoaded',resolve,{once:true}))
    : Promise.resolve();
  let latest = 0;
  async function handleOffer() {
    const code = location.hash.slice(1);
    const sequence = ++latest;
    if (code) history.replaceState(null,'',location.pathname);
    const result = /^[A-Za-z0-9_-]{32}$/.test(code)
      ? await chrome.runtime.sendMessage({to:'worker',type:'offer',code}).catch(()=>null)
      : null;
    await loaded;
    if (sequence !== latest) return;
    const message = document.querySelector('[role=status]');
    if (!message) return;
    message.dataset.companion = 'present';
    message.textContent = result?.ok
      ? 'Öffne im gewünschten Tab „Botmap Tab Sharing“, um ihn mit ' + result.people.join(', ') + ' zu teilen.'
      : 'Die Freigabe ist abgelaufen. Wähle am verbundenen Fenster in Botmap erneut „Tab teilen“.';
  }
  window.addEventListener('hashchange',handleOffer);
  void handleOffer();
}
