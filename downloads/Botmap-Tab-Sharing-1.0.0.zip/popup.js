const site = document.querySelector('#site');
const status = document.querySelector('[role=status]');
const allow = document.querySelector('#allow');
const stop = document.querySelector('#stop');
async function show() {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  const url = new URL(tab?.url || 'about:blank');
  const send = (type, extra = {}) => chrome.runtime.sendMessage({to:'worker', type, tab:tab.id, window:tab.windowId, ...extra});
  const state = await send('status');
  if (state?.active) {
    site.textContent = tab.title;
    stop.hidden = false;
    stop.onclick = async () => { await send('stop'); window.close(); };
    return;
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.origin==='http://127.0.0.1:44173' && url.pathname === '/tab-handoff.html') {
    status.textContent = 'Öffne die Website, die du gemeinsam bedienen möchtest.';
    return;
  }
  site.textContent = (tab.title || '') + ' · ' + url.host;
  const offer = await send('pending');
  if (!offer?.people?.length) {
    status.textContent = (state?.message ? state.message + ' ' : '') + 'Wähle zuerst „Tab teilen“ am verbundenen Browserfenster in Botmap.';
    return;
  }
  status.textContent = offer.people.join(', ') + (offer.people.length===1?' kann':' können') + ' in diesem Tab mit deiner Anmeldung klicken, schreiben und scrollen.';
  allow.hidden = false;
  allow.onclick = async () => {
    allow.disabled = true;
    try {
      const reply = await send('confirm', {offer:offer.id});
      if (!reply?.ok) throw Error(reply?.error || 'Die Freigabe ist abgelaufen.');
      window.close();
    } catch (error) {status.textContent = error.message; allow.hidden = true;}
  };
}
show().catch(() => {status.textContent='Der Tab ist nicht erreichbar. Öffne die Website und versuche es erneut.';});
