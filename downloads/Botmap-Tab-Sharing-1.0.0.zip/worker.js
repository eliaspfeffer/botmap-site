import {applyGesture} from './gesture.js';
const endpoint = 'http://127.0.0.1:44173';
const sessions=new Map(),starting=new Set();
let creating;
const off=(op,tab,extra={})=>chrome.runtime.sendMessage({to:'offscreen',op,tab,...extra});
async function local(op,secret,data={}) {
  const res=await fetch(endpoint+'/api/tab-companion',{method:'POST',credentials:'omit',redirect:'error',cache:'no-store',
    headers:{'Content-Type':'application/json','X-Botmap':'1',Authorization:'Bearer '+secret},body:JSON.stringify({op,...data}),signal:AbortSignal.timeout(3500)});
  if(!res.ok)throw Object.assign(Error('The Botmap share has ended or its code expired.'),{status:res.status});
  return res.json();
}
async function ensureOffscreen(){
  if(!creating)creating=(async()=>{
    if(!(await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT']})).length)
      await chrome.offscreen.createDocument({url:'offscreen.html',reasons:['USER_MEDIA'],justification:'Capture the tab the user approved for their Botmap peers.'});
  })().finally(()=>{creating=undefined;});
  await creating;
}
async function closeRecorderIfUnused(){
  if(!sessions.size && !starting.size)await chrome.offscreen.closeDocument().catch(()=>{});
}
async function stop(tab,s=sessions.get(tab)){
  if(!s||sessions.get(tab)!==s)return;
  sessions.delete(tab);await Promise.allSettled([off('stop',tab),local('end',s.secret,{}),chrome.action.setBadgeText({tabId:tab,text:''})]);
  await closeRecorderIfUnused();
}
async function viewport(tabId){
  const [v]=await chrome.scripting.executeScript({target:{tabId},func:()=>({width:innerWidth,height:innerHeight,origin:location.origin})});
  if(!v?.result||!v.documentId)throw Error('This page cannot be shared.');
  return {...v.result,document:v.documentId};
}
async function loop(tab,s){
  try{
    let ack,ok,misalignedSince=0;
    let retriedGeometry;
    while(sessions.get(tab)===s) {
      const v=await viewport(tab);
      const shot=await off('read',tab,{width:v.width,height:v.height});
      if(v.origin!==s.origin)throw Error('Die Website hat gewechselt.');
      if(!shot || shot.error)throw Error('Die Tabaufnahme wurde unterbrochen' + (shot?.error?' ('+shot.error+')':'') + '.');
      if(shot.waiting){await new Promise(r=>setTimeout(r,100));continue;}
      const current=await viewport(tab);
      if(current.document!==v.document || current.width!==v.width || current.height!==v.height)continue;
      if(Math.abs((shot.width/shot.height)/(v.width/v.height)-1)>.01) {
        if(!misalignedSince)misalignedSince=Date.now();
        if(Date.now()-misalignedSince>450){
          const geometry=[v.document,v.width,v.height].join('/');
          if(retriedGeometry===geometry)throw Error('Die Aufnahme konnte sich nicht an die neue Fenstergröße anpassen.');
          await local('resize',s.secret);
          await off('stop',tab);
          // Chromium releases a stopped capture asynchronously.
          for(let n=0;n<20;n++){
            const tracks=await chrome.tabCapture.getCapturedTabs();
            if(!tracks.some(t=>t.tabId===tab && ['pending','active'].includes(t.status)))break;
            await new Promise(r=>setTimeout(r,50));
          }
          const active=await viewport(tab);
          if(sessions.get(tab)!==s || active.origin!==s.origin) return;
          const streamId=await chrome.tabCapture.getMediaStreamId({targetTabId:tab});
          if(await off('start',tab,{streamId,width:active.width,height:active.height})!==true)
            throw Error('Die Aufnahme konnte nicht an die neue Fenstergröße angepasst werden.');
          retriedGeometry=geometry;misalignedSince=0;ack=undefined;ok=false;
        }
        await new Promise(r=>setTimeout(r,85));continue;
      }
      misalignedSince=0;retriedGeometry=undefined;
      if(sessions.get(tab)!==s)return;
      let reply;
      try {
        reply=await local('frame',s.secret,{image:shot.image,width:v.width,height:v.height,document:v.document,ack,ok});
      } catch(error) {
        if(error.status===403 || error.status===401)throw error;
        await new Promise(r=>setTimeout(r,800));continue;
      }
      ack=undefined;ok=false;
      if(reply.job && sessions.get(tab)===s) {
        const job=reply.job;ack=job.id;
        if(job.width===v.width && job.height===v.height){
          await local('claim',s.secret,{id:job.id});
          if(sessions.get(tab)!==s)return;
          const [r]=await chrome.scripting.executeScript({target:{tabId:tab,documentIds:[v.document]},func:applyGesture,args:[job.event,v.width,v.height]});
          ok=r?.result===true;
        }
      }
      await new Promise(r=>setTimeout(r,85));
    }
  } finally {await stop(tab,s);}
}
async function start(m){
  if(starting.has(m.tab)||sessions.has(m.tab))throw Error('This tab is already sharing.');
  if(!/^[A-Za-z0-9_-]{32}$/.test(m.code))throw Error('Wähle „Tab teilen“ erneut in Botmap.');
  starting.add(m.tab);let s;
  try {
    const tab=await chrome.tabs.get(m.tab);
    if(!tab.active||tab.windowId!==m.window||!/^https?:\/\//.test(tab.url||''))throw Error('Select this website and try again.');
    const v=await viewport(m.tab);
    const streamId=await chrome.tabCapture.getMediaStreamId({targetTabId:m.tab});
    const grant=await local('begin',m.code,{tab:m.tab,window:tab.windowId,title:tab.title});
    s={secret:grant.session,origin:v.origin};sessions.set(m.tab,s);
    await ensureOffscreen();
    const started=await off('start',m.tab,{streamId,width:v.width,height:v.height});
    if(started!==true)throw Error('Die Aufnahme konnte nicht starten' + (started?.error?' ('+started.error+')':'') + '.');
    await chrome.action.setBadgeText({tabId:m.tab,text:'ON'});
    void loop(m.tab,s).catch(e=>chrome.storage.session.set({['error:'+m.tab]:e.message}));
    return {ok:true};
  }catch(error){await stop(m.tab,s);throw error;}
  finally{starting.delete(m.tab);await closeRecorderIfUnused();}
}
// session storage survives MV3 worker suspension and is cleared on browser exit.
// Each confirmation references the exact offer shown in that popup.
const offerKey = id => 'offer:' + id;
async function receiveOffer(code, sender) {
  if (!/^[A-Za-z0-9_-]{32}$/.test(code)) throw Error('Invalid sharing request.');
  const offer = await local('describe',code);
  const windowId = offer.window ?? sender.tab.windowId;
  if (!Number.isInteger(windowId) || !offer.people?.length) throw Error('No connected window.');
  const id = crypto.randomUUID();
  await chrome.storage.session.set({[offerKey(windowId)]:{id,code,people:offer.people,expires:offer.expires}});
  return {ok:true,people:offer.people};
}
async function pending(windowId) {
  const key = offerKey(windowId);
  const offer = (await chrome.storage.session.get(key))[key];
  return offer?.expires > Date.now() ? offer : null;
}
async function confirm(message) {
  const offer = await pending(message.window);
  if (!offer || offer.id !== message.offer) throw Error('Wähle „Tab teilen“ erneut in Botmap.');
  await chrome.storage.session.remove('error:'+message.tab);
  const result = await start({...message,code:offer.code});
  const key = offerKey(message.window);
  if ((await pending(message.window))?.id === offer.id) await chrome.storage.session.remove(key);
  return result;
}
chrome.runtime.onMessage.addListener((m,sender,send)=>{
  if(m.to!=='worker'||sender.id!==chrome.runtime.id)return false;
  const popup=sender.url===chrome.runtime.getURL('popup.html'), recorder=sender.url===chrome.runtime.getURL('offscreen.html');
  const handoff = sender.frameId === 0 && sender.tab && sender.url?.split('#')[0] === endpoint+'/tab-handoff.html';
  if(!popup && !(recorder && m.type==='ended') && !(handoff && m.type==='offer'))return false;
  if(m.type==='status'){
    chrome.storage.session.get('error:'+m.tab).then(r=>send({active:sessions.has(m.tab),message:r['error:'+m.tab]}));
    return true;
  }
  let work;
  if (handoff && m.type==='offer') work=receiveOffer(m.code,sender);
  else if (popup && m.type==='pending') work=pending(m.window).then(offer=>offer && {id:offer.id,people:offer.people});
  else if (popup && m.type==='confirm') work=confirm(m);
  else if (m.type==='stop' || m.type==='ended') work=stop(m.tab);
  else return false;
  Promise.resolve(work).then(r=>send(r??true),e=>send({ok:false,error:e.message}));return true;
});
chrome.tabs.onRemoved.addListener(id=>void stop(id));
chrome.tabs.onDetached.addListener(id=>void stop(id));
chrome.tabs.onUpdated.addListener((id,change)=>{const s=sessions.get(id);if(s&&change.url&&new URL(change.url).origin!==s.origin)void stop(id,s);});
